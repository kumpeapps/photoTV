mkdir /jkupdate/update-files
cd /jkupdate/update-files
rm /jkupdate/update-files/*.*
sudo cp /media/usb/jkupdate.zip /jkupdate/update-files/jkupdate.zip
sudo 7za x -y -p{LetmeN2it} jkupdate.zip
sudo rm /media/usb/jkupdate.zip
sudo sh /jkupdate/update-files/update.sh
sudo cp /media/usb/jkcustomize.zip /jkupdate/update-files/jkcustomize.zip
sudo 7za x -y -p{LetmeN2it} jkcustomize.zip
sudo rm /media/usb/jkcustomize.zip
sudo sh /jkupdate/update-files/customize.sh