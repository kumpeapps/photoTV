sudo apt update
sudo mkdir /media/usb
sudo mount /dev/sda1 /media/usb
sudo mkdir /jkupdate
sudo mkdir /jkupdate/update-files
sudo mkdir /phototv-files
sudo mkdir /phototv-files/alternate
sudo mkdir /jkupdate
sudo systemctl disable getty@tty1
sudo timedatectl set-timezone "America/Chicago"
sudo cp /phototv-files/splashscreen.service /etc/systemd/system/splashscreen.service
sudo cp /phototv-files/splash.png /opt/splash.png
sudo cp /phototv-files/index.php /var/www/html/index.php
sudo cp /phototv-files/run.php /var/www/html/run.php
sudo rm /var/www/html/index.html
sudo cp /phototv-files/autostart-01sec /phototv-files/alternate/autostart-01sec
sudo cp /phototv-files/autostart-05sec /phototv-files/alternate/autostart-05sec
sudo cp /phototv-files/autostart-10sec /phototv-files/alternate/autostart-10sec
sudo cp /phototv-files/autostart-15sec /phototv-files/alternate/autostart-15sec
sudo cp /phototv-files/autostart-20sec /phototv-files/alternate/autostart-20sec
sudo cp /phototv-files/autostart-25sec /phototv-files/alternate/autostart-25sec
sudo cp /phototv-files/autostart-30sec /phototv-files/alternate/autostart-30sec
sudo cp /phototv-files/interfaces-adhoc /phototv-files/interfaces-adhoc
sudo cp /phototv-files/dhcpd.conf /phototv-files/dhcpd.conf
sudo cp /phototv-files/adhoc_setup.sh /phototv-files/adhoc_setup.sh
sudo cp /phototv-files/adhoc_disable.sh /phototv-files/adhoc_disable.sh
sudo cp /phototv-files/getserial.sh /phototv-files/getserial.sh
sudo cp /phototv-files/jkupdate.sh /jkupdate/jkupdate.sh
sudo systemctl enable splashscreen
sudo cp /phototv-files/rc.local /etc/rc.local
sudo cp /phototv-files/everyboot.sh /phototv-files/everyboot.sh
sudo cp /phototv-files/interfaces /phototv-files/interfaces
sudo cp /phototv-files/autostart /phototv-files/autostart
sudo cp /phototv-files/splash.png /usr/share/plymouth/themes/pix/splash.png
sudo cp /phototv-files/wallpaper.jpg /phototv-files/wallpaper.jpg
sudo cp /phototv-files/desktop-items-0.conf /phototv-files/desktop-items-0.conf
sudo cp /phototv-files/envvars /etc/apache2/envvars
sudo cp /phototv-files/launch.png /usr/share/raspberrypi-artwork/launch.png
sudo cp /phototv-files/raspberry-pi-logo.png /usr/share/raspberrypi-artwork/raspberry-pi-logo.png
sudo cp /phototv-files/raspberry-pi-logo-small.png /usr/share/raspberrypi-artwork/raspberry-pi-logo-small.png
sudo cp /phototv-files/raspitr.png /usr/share/raspberrypi-artwork/raspitr.png
sudo ufw default allow outgoing
sudo ufw default deny incoming
sudo ufw allow www
sudo ufw allow ssh
sudo ufw allow vnc
echo "y" | sudo ufw enable
