sudo cp /phototv-files/autostart /home/pi/.config/lxsession/LXDE-pi/autostart
sudo cp /phototv-files/desktop-items-0.conf /home/pi/.config/pcmanfm/LXDE-pi/desktop-items-0.conf