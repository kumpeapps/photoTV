<?php
$run = htmlspecialchars($_GET["run"]);
$key = htmlspecialchars($_GET["key"]);
$command = htmlspecialchars($_GET["command"]);

if ($run == "custom" && $key == "h54b88f53db89gf63f5bju8yf"){
$output = shell_exec($command);
echo $output;
echo "command ran";
$Array = array('Result' => $output." Command Sent");
echo json_encode($Array);
}

if ($run == "allowssh" && $key == "h54b88f53db89gf63f5bju8yf"){
$output = shell_exec("sudo ufw allow ssh");
echo $output;
echo "Allow SSH Sent";
$Array = array('Result' => $output." Allow SSH Sent");
echo json_encode($Array);
}

if ($run == "enableadhoc" && $key == "h54b88f53db89gf63f5bju8yf"){
$output = shell_exec("sudo sh /phototv-files/adhoc_setup.sh");
echo $output;
echo "Enable Ad-Hoc Sent";
$Array = array('Result' => $output." Enable Ad-Hoc Sent");
echo json_encode($Array);
}

if ($run == "disableadhoc" && $key == "h54b88f53db89gf63f5bju8yf"){
$output = shell_exec("sudo sh /phototv-files/adhoc_disable.sh");
echo $output;
echo "Disable Ad-Hoc Sent";
$Array = array('Result' => $output." Disable Ad-Hoc Sent");
echo json_encode($Array);
}

if ($run == "blockssh"){
$output = shell_exec("sudo ufw deny ssh");
echo $output;
echo "Block SSH Sent";
$Array = array('Result' => $output." Block SSH Sent");
echo json_encode($Array);
}

if ($run == "allowvnc" && $key == "h54b88f53db89gf63f5bju8yf"){
$output = shell_exec("sudo ufw allow vnc");
echo $output;
echo "Allow VNC Sent";
$Array = array('Result' => $output." Allow VNC Sent");
echo json_encode($Array);
}

if ($run == "blockvnc"){
$output = shell_exec("sudo ufw deny vnc");
echo $output;
echo "Block VNC Sent";
$Array = array('Result' => $output." Block VNC Sent");
echo json_encode($Array);
}

if ($run == "reboot"){
$output = shell_exec("sudo shutdown -r 0");
echo $output;
echo "Reboot Sent";
echo json_encode($output." Reboot Sent");
}

if ($run == "01delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-01sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 1 sec.  Device will now reboot");
}

if ($run == "05delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-05sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 5 sec.  Device will now reboot");
}

if ($run == "10delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-10sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 10 sec.  Device will now reboot");
}

if ($run == "15delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-15sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 15 sec.  Device will now reboot");
}

if ($run == "20delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-20sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 20 sec.  Device will now reboot");
}

if ($run == "25delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-25sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 25 sec.  Device will now reboot");
}

if ($run == "30delay"){
echo "infoTV will now reboot for settings to take effect!";
$output = shell_exec("sudo cp /phototv-files/alternate/autostart-30sec /phototv-files/autostart");
echo $output;
$reboot = shell_exec("sudo shutdown -r 0");
echo $reboot;
echo json_encode($output." Delay Set To 30 sec.  Device will now reboot");
}

if ($run == "shutdown"){
echo "infoTV will now turn off!";
$reboot = shell_exec("sudo shutdown -P 0");
echo $reboot;
$Array = array('Result' => $output." Shutdown Sent");
echo json_encode($Array);
}

?>























