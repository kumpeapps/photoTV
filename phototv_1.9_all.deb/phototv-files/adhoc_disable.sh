sudo cp /phototv-files/interfaces /etc/network/interfaces
sudo apt remove isc-dhcp-server -y
sudo reboot
