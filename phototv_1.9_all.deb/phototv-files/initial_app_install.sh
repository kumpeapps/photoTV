sudo apt update
sudo apt upgrade -y
sudo apt update
sudo apt auto-remove -y
sudo apt update
sudo apt install feh -y
sudo apt install fbi -y
sudo apt install xtrlock -y
sudo apt install apache2 php -y
sudo apt install ufw -y
sudo apt install p7zip-full -y
sudo reboot
