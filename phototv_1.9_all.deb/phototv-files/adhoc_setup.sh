sudo mkdir /phototv-files
sudo cp /etc/network/interfaces /etc/network/interfaces-wifi
sudo cp /phototv-files/interfaces-adhoc /etc/network/interfaces
sudo apt install isc-dhcp-server -y
sudo cp /phototv-files/dhcpd.conf /etc/dhcp/dhcpd.conf
sudo ufw deny vnc
sudo ufw deny ssh
sudo reboot
