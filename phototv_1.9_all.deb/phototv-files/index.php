<?php 


echo "<div align='center'><br>";
echo "<u><b>photoTV Configuration</b></u>  <br><br><br>";
echo "<form action='' method='post'>";

echo "<button type='submit' formaction='/run.php?run=reboot'>Reboot</button>";
echo "<br><button type='submit' formaction='/run.php?run=shutdown'> Shutdown </button>";
echo "<br><button type='submit' formaction='/run.php?run=01delay'> Change Slide Delay to 1 sec </button>";
echo "<br><button type='submit' formaction='/run.php?run=05delay'> Change Slide Delay to 5 sec </button>";
echo "<br><button type='submit' formaction='/run.php?run=10delay'> Change Slide Delay to 10 sec </button>";
echo "<br><button type='submit' formaction='/run.php?run=15delay'> Change Slide Delay to 15 sec </button>";
echo "<br><button type='submit' formaction='/run.php?run=20delay'> Change Slide Delay to 20 sec </button>";
echo "<br><button type='submit' formaction='/run.php?run=25delay'> Change Slide Delay to 25 sec </button>";
echo "<br><button type='submit' formaction='/run.php?run=30delay'> Change Slide Delay to 30 sec </button>";
echo "</form>";
   
?> 

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" 
"http://www.w3.org/TR/html4/loose.dtd"> 
<html> 
<head> 
      <title>MOKA-E InfoTV System</title> 
      </head> 

<body> 	<body onload="preloadImages();" bgcolor="#81CB2D">
		<div align="left">
			<csactiondict>
				<script type="text/javascript"><!--


// --></script>
			</csactiondict>
		</div>
		<div align="center"><br>

</form><br><br>

<br>
<br>
<code id="body1"></code><br>
<code id="body2"></code><br>
<code id="body3"></code><br>
<code id="body4"></code><br>
<code id="body5"></code><br><br>

</div>


<script>

	
function reboot() {
    
}

	

	
	</script>